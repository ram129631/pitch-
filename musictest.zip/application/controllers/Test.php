<?php
class Test extends CI_Controller
{
	
}
?>